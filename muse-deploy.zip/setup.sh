#!/bin/bash
set -e
cd "$(dirname "$0")"

if command -v python3 &>/dev/null; then PY=python3; else PY=python; fi
echo "Python: $($PY --version 2>&1)"

if [ ! -d venv ]; then
    $PY -m venv venv
fi
source venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt

echo
$PY -c "import curl_cffi, cryptography; print('deps OK:', curl_cffi.__version__, cryptography.__version__)"
echo
echo "Selesai. Jalankan: ./run.sh"
